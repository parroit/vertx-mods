
from org.vertx.java.core.json import JsonObject, JsonArray
from org.vertx.java.busmods import BusModBase
from idlelib.CallTipWindow import container
import vertx
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm.session import sessionmaker
from sqlalchemy import create_engine
from sqlalchemy.schema import Table, MetaData, Column
from sqlalchemy.types import *


db_path = 'sqlite:///app/db/ecm.db'


Base = declarative_base()


class AlchemyPersistor (BusModBase):
    """
* Alchemy Persistor Bus Module<p>
* Please see the busmods manual for a full description<p>
*
* @author <a href="http://tfox.org">Tim Fox</a>
* @author Thomas Risberg
* @author andrea.parodi@ebansoftware.net Andrea Parodi
*/  
"""

    metadata = MetaData()

    User = Table('users', metadata,
        Column('name', Integer, primary_key = True),
        Column('password', String(16), nullable = False),
        Column('email', String(60)),
        Column('confirmed', String(20), nullable = False)
    )






    def create_new_session(self):
        return  self.Session(bind=self.engine.connect())


    def start(self):
        super.start()
        self.address = self.getOptionalStringConfig("address", "default");
        self.protocol = self.getOptionalStringConfig("protocol", "sqlite")
        self.host = self.getOptionalStringConfig("host", "")
        self.dbName = self.getOptionalStringConfig("db_name", "/db/default.db")
        self.username = self.getOptionalStringConfig("username", None)
        self.password = self.getOptionalStringConfig("password", None)
        self.db_path = self.protocol+"://"+self.host+self.dbName
        container.eventBus().registerHandler(self.address, self);

        self.engine = create_engine(self.db_path, echo=False)

        metadata = Base.metadata
        metadata.create_all(self.engine)

        self.Session = sessionmaker(bind=self.engine)





    def stop(self) :
        self.engine.disconnect()

    def handle(self,msg) :

        action = msg.body.getString("action")

        if action is None:
          self.sendError(msg, "action must be specified")
          return

        {
        'save': lambda msg:self._doSave(msg),
        'find':  lambda msg:self._doFind(msg),
        'findone': lambda msg:self._doFindOne(msg),
        'delete': lambda msg:self._doDelete(msg),
        }.get(action, lambda msg:self.sendError(msg, "Invalid action: " + action))





    def _doSave(self,message) :
        collection = self.getMandatoryString("collection", message)
        if collection is None:
          return

        doc = self.getMandatoryObject("document", message)
        if doc is None:
          return

        session = self.create_new_session()
        session.save(doc)
        saved_doc = session.load(doc)

        self.sendOK(message, saved_doc)





    def _doFind(self, message) :
        print("_doFind start")
        collection = self.getMandatoryString("collection", message)
        if collection is None:
          return

        limit =message.body.getNumber("limit")
        if limit is None:
          limit = -1

        matcher = self.getMandatoryObject("matcher", message)
        if matcher is None:
            return


        page = self.getMandatoryObject("page", message)
        if page is None:
            return

        sort = message.body.getObject("sort")
        session = self.create_new_session()
        def timeout_handle(error,msg) :
            container.getLogger().warn("Closing DB cursor on timeout")
            try :
                session.close()
            except () :
                pass
            self.sendError("timeout error")

        timerID = vertx.setTimer(10000,timeout_handle)

        rows = session.query(self[collection]).filter(matcher)
        total_rows = rows.count ()
        rows = rows.limit(limit).offset( limit*(page-1) ).order_by(sort).all()
        pages= int(total_rows / self.page_len)
        if total_rows % self.page_len>0:
            pages+=1



        self._sendResults(message, rows, pages,total_rows)

    def _sendResults(self,message, rows,  pages,total_rows) :
        count = 0


        #Set a timeout, if the user doesn't reply within 10 secs, close the cursor

        results = JsonArray()
        for obj in rows:
            results.add(JsonObject(obj))
            count+=1


        reply = JsonObject().putArray("rows", results).putNumber("pages", pages).putNumber("total_rows", total_rows)
        self.sendOK(message, results)





    def _doFindOne(self,message) :
        collection = self.getMandatoryString("collection", message)
        if collection is None:
            return

        matcher = self.getMandatoryObject("matcher", message)
        if matcher is None:
            return

        session = self.create_new_session()
        rows = session.query(self[collection]).filter(matcher)

        self._sendResults(message, rows,1)


    def _doDelete(self,message) :
        collection = self.getMandatoryString("collection", message)
        if collection is None:
            return



        matcher = self.getMandatoryObject("matcher", message)
        if matcher is None:
            return


        session = self.create_new_session()
        rows = session.query(self[collection]).filter(matcher)
        deleted=session.delete(rows)

        self.sendOK(message, JsonObject().putNumber("number", deleted))



